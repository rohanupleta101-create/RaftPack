Ember Studios - Raft Survival Pack
For Minecraft Java 1.21.11 (pack format 75).
Includes pause menu, raft textures, thirst HUD, crate preview GUIs, rank tags and custom items.
